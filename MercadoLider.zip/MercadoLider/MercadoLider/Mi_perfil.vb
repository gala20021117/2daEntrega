﻿Imports System.ComponentModel
Imports MySql.Data.MySqlClient

Public Class frmPerfil
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user333; Pwd=171102,Megals;"
    Dim conexion As New MySqlConnection(server)
    Dim cmd As New MySqlCommand

    Private Sub btnEditar_Click(sender As Object, e As EventArgs) Handles btnEditar.Click
        Try
            conexion.Open()
            cmd = conexion.CreateCommand
            cmd.CommandText = "UPDATE usuarios, contactousuario SET Nombre = @Nombre, Apellido = @Apellido, Email = @Email, Telefono = @Telefono, Departamento = @Departamento, Ciudad = @Ciudad, Calle = @Calle, NumCasa = @NumCasa WHERE usuarios.IdUsuario = @IdUsuario"
            cmd.Prepare()
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text)
            cmd.Parameters.AddWithValue("@Apellido", txtApellido.Text)
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text)
            cmd.Parameters.AddWithValue("@Telefono", txtTelefono.Text)
            cmd.Parameters.AddWithValue("@Departamento", txtDep.Text)
            cmd.Parameters.AddWithValue("@Ciudad", txtCiudad.Text)
            cmd.Parameters.AddWithValue("@Calle", txtDomicilio.Text)
            cmd.Parameters.AddWithValue("@NumCasa", txtCasa.Text)
            cmd.Parameters.AddWithValue("@IdUsuario", txtCI.Text)
            cmd.ExecuteNonQuery()
            'MsgBox("Conexión establecida.")
            conexion.Close()


        Catch ex As Exception

        End Try

    End Sub

    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnGuardar.Click
        Try
            If Me.ValidateChildren And txtNombre.Text <> String.Empty And txtApellido.Text <> String.Empty And txtEmail.Text <> String.Empty And txtCI.Text <> String.Empty And txtTelefono.Text <> String.Empty And txtDep.Text <> String.Empty And txtCiudad.Text <> String.Empty And txtDomicilio.Text <> String.Empty And txtCasa.Text <> String.Empty Then
                MessageBox.Show("Datos correctamente registrados", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Ingrese todos los datos", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub txtNombre3_Validating(sender As Object, e As CancelEventArgs) Handles txtNombre.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un nombre")

        End If
    End Sub

    Private Sub txtApellido3_Validating(sender As Object, e As CancelEventArgs) Handles txtApellido.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un apellido")

        End If
    End Sub

    Private Sub txtEmail3_Validating(sender As Object, e As CancelEventArgs) Handles txtEmail.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un Email")

        End If
    End Sub

    Private Sub txtCI3_Validating(sender As Object, e As CancelEventArgs) Handles txtCI.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese su cedula")

        End If
    End Sub

    Private Sub txtTelefono3_Validating(sender As Object, e As CancelEventArgs) Handles txtTelefono.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un telefono o celular")

        End If
    End Sub

    Private Sub txtDep3_Validating(sender As Object, e As CancelEventArgs) Handles txtDep.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un departamento")

        End If
    End Sub

    Private Sub txtCiudad3_Validating(sender As Object, e As CancelEventArgs) Handles txtCiudad.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese una ciudad")

        End If
    End Sub

    Private Sub txtDomicilio3_Validating(sender As Object, e As CancelEventArgs) Handles txtDomicilio.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un domicilio")

        End If
    End Sub

    Private Sub txtCasa3_Validating(sender As Object, e As CancelEventArgs) Handles txtCasa.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un numero de casa o apt")

        End If
    End Sub

    Private Sub txtNombre3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNombre.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtApellido3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtApellido.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtCI3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCI.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtTelefono3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTelefono.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtDep3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDep.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtCiudad3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCiudad.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtDomicilio3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDomicilio.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtCasa3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCasa.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub btnCancelar2_Click(sender As Object, e As EventArgs) Handles btnCancelar2.Click
        End

    End Sub
    Private Sub btnVentas_Click(sender As Object, e As EventArgs) Handles btnVentas.Click
        frmVentas.Show()
    End Sub

    Private Sub btnVender_Click(sender As Object, e As EventArgs) Handles btnVender.Click
        frmVender.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        frmPublicaciones.Show()
    End Sub

    Private Sub frmPerfil_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnCompras_Click_1(sender As Object, e As EventArgs) Handles btnCompras.Click
        frmMisCompras.Show()
    End Sub
End Class