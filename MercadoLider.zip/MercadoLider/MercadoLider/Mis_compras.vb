﻿Imports MySql.Data.MySqlClient
Public Class frmMisCompras
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user333; Pwd=171102,Megals;"
    Dim conexion As New MySqlConnection(server)
    Dim cmd As New MySqlCommand
    Dim adaptador As New MySqlDataAdapter
    Dim ds As DataSet = New DataSet
    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        End
    End Sub

    Sub ActualizarSelect()
        Try
            conexion.Open()
            'MsgBox("nos conectamos")
            cmd.Connection = conexion

            cmd.CommandText = "SELECT * FROM compras"
            adaptador.SelectCommand = cmd
            adaptador.Fill(ds, "Tabla")
            grdCompras.DataSource = ds
            grdCompras.DataMember = "Tabla"

            conexion.Close()

            ' MsgBox("Fue ingresado su registro ")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub frmMisCompras_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActualizarSelect()
    End Sub

End Class