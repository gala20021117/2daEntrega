﻿Imports System.ComponentModel
Imports MySql.Data.MySqlClient
Public Class frmContraseña
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user333; Pwd=171102,Megals;"
    Dim conexion As New MySqlConnection(server)
    Dim cmd As New MySqlCommand

    Private Sub btnAceptar_Click(sender As Object, e As EventArgs) Handles btnAceptar.Click

        If Me.ValidateChildren And txtCI.Text <> String.Empty And txtCont.Text <> String.Empty And txtCont2.Text <> String.Empty Then


            If txtCont.Text <> txtCont2.Text Then
                MsgBox("Las contraseñas no coinciden")

            ElseIf txtCont.Text = txtCont2.Text Then

                Try
                    conexion.Open()
                    cmd = conexion.CreateCommand
                    cmd.CommandText = "UPDATE `usuarios` SET `Contraseña` = '" + txtCont.Text + "' WHERE `IdUsuario` = @IdUsuario"
                    cmd.Prepare()
                    cmd.Parameters.Clear()

                    cmd.Parameters.AddWithValue("@Contraseña", txtCont.Text)
                    cmd.Parameters.AddWithValue("@IdUsuario", txtCI.Text)
                    cmd.ExecuteNonQuery()

                    txtCI.Clear()
                    txtCont.Clear()
                    txtCont2.Clear()
                    conexion.Close()

                    MessageBox.Show("Datos correctamente ingresados", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    frmIngreso.Show()

                Catch ex As Exception
                    MsgBox(ex.Message)
                    conexion.Close()
                End Try
            Else
                MessageBox.Show("Ingrese todos los datos", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub txtEmail_Validating(sender As Object, e As CancelEventArgs) Handles txtCI.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese su Email")

        End If
    End Sub

    Private Sub txtCont_Validating(sender As Object, e As CancelEventArgs) Handles txtCont.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese su contraseña")

        End If
    End Sub

    Private Sub txtCont2_Validating(sender As Object, e As CancelEventArgs) Handles txtCont2.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Repita su contraseña")

        End If
    End Sub
    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        End

    End Sub

    Private Sub frmContraseña_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class