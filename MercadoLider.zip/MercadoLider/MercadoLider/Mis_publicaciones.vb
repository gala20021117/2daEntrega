﻿Imports MySql.Data.MySqlClient
Public Class frmPublicaciones
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user333; Pwd=171102,Megals;"
    Dim conexion As New MySqlConnection(server)
    Dim cmd As New MySqlCommand
    Dim ds As DataSet = New DataSet
    Dim adaptador As MySqlDataAdapter = New MySqlDataAdapter
    Dim tabla As DataTable

    Sub ActualizarSelect()
        Try
            conexion.Open()
            'MsgBox("nos conectamos")
            cmd.Connection = conexion

            cmd.CommandText = "SELECT articulos.Codigo, articulos.Nombre, articulos.Precio, articulos.Descripcion, articulos.IdCategoria, categoria.Nombre FROM articulos, categoria WHERE articulos.IdCategoria=categoria.IdCategoria"
            adaptador.SelectCommand = cmd
            adaptador.Fill(ds, "Tabla")
            grdArticulos.DataSource = ds
            grdArticulos.DataMember = "Tabla"

            conexion.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Try
            adaptador = New MySqlDataAdapter("SELECT IdCategoria, Nombre FROM categoria", conexion)
            tabla = New DataTable
            adaptador.Fill(tabla)

            Call LlenarComoBox()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Mis_publicaciones_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ActualizarSelect()
    End Sub

    Private Sub btnEditar_Click(sender As Object, e As EventArgs) Handles btnEditar.Click
        Try
            conexion.Open()
            'MsgBox("nos conectamos")
            cmd.Connection = conexion

            cmd.CommandText = "UPDATE `articulos` SET `Nombre` = '" + txtArticulo.Text + "', `Precio` = '" + txtPrecio.Text + "', `Descripcion` = '" + txtDesc.Text + "', `IdCategoria` = '" + cmbCategoria.Text + "' WHERE `articulos`.`Codigo` = @Codigo;"
            cmd.Prepare()

            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@nombre", txtArticulo.Text)
            cmd.Parameters.AddWithValue("@Precio", txtPrecio.Text)
            cmd.Parameters.AddWithValue("@Descripción", txtDesc.Text)
            cmd.Parameters.AddWithValue("@Categoría", txtDesc.Text)
            cmd.Parameters.AddWithValue("@Codigo", txtCodigo.Text)
            cmd.Parameters.AddWithValue("@IdCategoria", cmbCategoria.Text)
            cmd.ExecuteNonQuery()

            txtArticulo.Clear()
            txtPrecio.Clear()
            txtDesc.Clear()
            txtCodigo.Clear()
            cmbCategoria.Text = ""

            conexion.Close()

            ActualizarSelect()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub grdArticulos_SelectionChanged(sender As Object, e As EventArgs) Handles grdArticulos.SelectionChanged
        If (grdArticulos.SelectedRows.Count > 0) Then
            txtArticulo.Text = grdArticulos.Item("nombre", grdArticulos.SelectedRows(0).Index).Value
            txtPrecio.Text = grdArticulos.Item("Precio", grdArticulos.SelectedRows(0).Index).Value
            txtDesc.Text = grdArticulos.Item("Descripcion", grdArticulos.SelectedRows(0).Index).Value
            txtCodigo.Text = grdArticulos.Item("Codigo", grdArticulos.SelectedRows(0).Index).Value
        End If
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        Dim respuesta As Byte

        respuesta = MsgBox("¿Esta seguro que desea eliminar este registro?", vbYesNo, "Eliminar")
        If respuesta = vbYes Then

            Try
                conexion.Open()
                cmd.Connection = conexion
                cmd.CommandText = "DELETE FROM `articulos` WHERE `articulos`.`Codigo` = @Codigo;"
                cmd.Prepare()
                cmd.Parameters.Clear()

                cmd.Parameters.AddWithValue("@Nombre", txtArticulo.Text)
                cmd.Parameters.AddWithValue("@Precio", txtPrecio.Text)
                cmd.Parameters.AddWithValue("@Descripcion", txtDesc.Text)
                cmd.Parameters.AddWithValue("@Codigo", txtCodigo.Text)
                cmd.ExecuteNonQuery()

                txtArticulo.Clear()
                txtPrecio.Clear()
                txtDesc.Clear()
                txtCodigo.Clear()

                conexion.Close()

                ActualizarSelect()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If
    End Sub
    Private Sub LlenarComoBox()
        For Each fila As DataRow In tabla.Rows
            cmbCategoria.Items.Add(fila("IdCategoria"))
            cmbCategoria.Items.Add(fila("Nombre"))
        Next
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        End
    End Sub
End Class